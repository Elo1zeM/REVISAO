// Criar arquivo hello.js
// 

// Criar uma variável com seu nome
const meuNome = "Eloize";

// Criar uma função que mostre uma mensagem de boas-vindas
function exibirBoasVindas() {
    console.log("Olá,",meuNome,"! Seja bem-vindo ao Node.js!")
}

// Chama a função
exibirBoasVindas()
// TODO: Adicione uma mensagem mostrando a versão do Node.js

console.log("Versão do Node.js:", process.version);
