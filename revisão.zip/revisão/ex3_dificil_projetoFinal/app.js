// projeto-final/app.js

const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3005;

// TODO: Configure todos os middlewares necessários
app.use(express.json() );
// TODO: Implemente sistema de usuários com JSON
const usuarios = [
    { id: 1, nome: 'Isabella Roberta', email: 'isabella.roberta@gmail.com', idade: 37 },
    { id: 2, nome: 'Guilherme Oliveira', email: 'gui.oliveira@gmail.com', idade: 21 },
    { id: 3, nome: 'Amanda de Carmo', email: 'amanda.dcarmo@gmail.com', idade: 17 },
]

let proximoId = 4;

// TODO: Crie rotas protegidas e públicas

// ROTA GET: Listar todos os usuarios
app.get('/usuarios', (req, res) => {
    // Retorna a lista completa de usuarios
    res.json(usuarios);
});

// ROTA GET: Buscar usuario por ID
app.get('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const usuarios = usuarios.find(p => p.id === id);
    
    if (usuarios) {
        res.json(usuarios);
    } else {
        res.status(404).json({ erro: 'Usuário não encontrado!' });
    }
});

// ROTA POST: Criar um novo usuario
app.post('/usuarios', (req, res) => {
    const { nome, email, idade } = req.body;
    
    // Validação básica para garantir que todos os campos foram enviados
    if (!nome || !email || !idade) {
        return res.status(400).json({ erro: 'Nome, email e idade são obrigatórios' });
    }
    
    // Cria o novo usuario com um ID automático
    const novoUsuario = {
        id: proximoId,
        nome: nome,
        email: email,
        idade: idade
    };
    
    // Incrementa o ID para o próximo usuario a ser criado
    proximoId++;
    
    // Adiciona o novo usuario ao array "usuario"
    usuarios.push(novoUsuario);
    
    // Retorna o usuario recém-criado com o status 201 (Created)
    res.status(201).json(novoUsuario);
});

// ROTA PUT: Atualizar um usuario existente
app.put('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = usuarios.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Usuário não encontrado' });
    }
    
    // Atualiza o usuario no array
    // Mantém o ID original e atualiza os outros campos com os dados da requisição
    usuarios[index] = { ...usuarios[index], ...req.body };
    
    res.json(usuarios[index]);
});

// ROTA DELETE: Remover um usuario
app.delete('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = usuarios.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Usuário não encontrado' });
    }
    
    // Remove o usuario do array usando o índice encontrado
    usuarios.splice(index, 1);
    
    // Retorna o status 204 (No Content) para indicar sucesso na remoção
    res.status(204).send();
});
// TODO: Adicione sistema de upload
// TODO: Implemente tratamento de erros
// TODO: Crie documentação das rotas

// Estrutura sugerida:
// /auth/login - POST
// /auth/register - POST
// /users - GET, POST, PUT, DELETE
// /upload - POST
// /files - GET
// /docs - GET (documentação)

app.listen(PORT, () => {
    console.log(`🚀 Projeto Final rodando em http://localhost:${PORT}`);
});