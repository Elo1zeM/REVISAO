const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3005;

// Middlewares
app.use(express.json());

// Caminhos dos arquivos
const usuariosPath = path.join(__dirname, 'data', 'usuarios.json');

// Usuários iniciais
const usuariosIniciais = [
    { id: 1, nome: 'Eloize Muzel', email: 'eloizemuzel@gmail.com', idade: 16, senha: '123' },
    { id: 2, nome: 'Maria Silva', email: 'mariasilva@gmail.com', idade: 17, senha: '456' },
    { id: 3, nome: 'Elena Maria', email: 'elenamaria@gmail.com', idade: 20, senha: '789' },
];

// Criar pasta /data se não existir
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

// Criar arquivo usuarios.json se não existir
if (!fs.existsSync(usuariosPath)) {
    fs.writeFileSync(usuariosPath, JSON.stringify(usuariosIniciais, null, 2));
}

// Funções auxiliares para manipular usuários
function lerUsuarios() {
    const data = fs.readFileSync(usuariosPath);
    return JSON.parse(data);
}

function salvarUsuarios(usuarios) {
    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
}

// Rotas de usuários
app.get('/users', (req, res) => {
    const usuarios = lerUsuarios();
    res.json(usuarios);
});

app.post('/users', (req, res) => {
    const usuarios = lerUsuarios();
    const novoUsuario = {
        id: Date.now(),
        ...req.body
    };
    usuarios.push(novoUsuario);
    salvarUsuarios(usuarios);
    res.status(201).json(novoUsuario);
});

app.put('/users/:id', (req, res) => {
    const usuarios = lerUsuarios();
    const id = parseInt(req.params.id);
    const index = usuarios.findIndex(u => u.id === id);

    if (index === -1) {
        return res.status(404).json({ erro: 'Usuário não encontrado' });
    }

    usuarios[index] = { ...usuarios[index], ...req.body };
    salvarUsuarios(usuarios);
    res.json(usuarios[index]);
});

app.delete('/users/:id', (req, res) => {
    const usuarios = lerUsuarios();
    const id = parseInt(req.params.id);
    const novosUsuarios = usuarios.filter(u => u.id !== id);

    if (usuarios.length === novosUsuarios.length) {
        return res.status(404).json({ erro: 'Usuário não encontrado' });
    }

    salvarUsuarios(novosUsuarios);
    res.status(204).send();
});

// Rotas de autenticação
app.post('/auth/register', (req, res) => {
    const { nome, email, senha, idade } = req.body;
    if (!email || !senha || !nome) {
        return res.status(400).json({ erro: 'Nome, email e senha são obrigatórios' });
    }

    const usuarios = lerUsuarios();
    if (usuarios.find(u => u.email === email)) {
        return res.status(400).json({ erro: 'Email já cadastrado' });
    }

    const novoUsuario = {
        id: Date.now(),
        nome,
        email,
        senha, // Em produção, criptografe isso
        idade
    };

    usuarios.push(novoUsuario);
    salvarUsuarios(usuarios);

    res.status(201).json({
        mensagem: 'Usuário registrado com sucesso',
        usuario: { id: novoUsuario.id, nome, email }
    });
});

app.post('/auth/login', (req, res) => {
    const { email, senha } = req.body;
    const usuarios = lerUsuarios();
    const usuario = usuarios.find(u => u.email === email && u.senha === senha);

    if (!usuario) {
        return res.status(401).json({ erro: 'Credenciais inválidas' });
    }

    res.json({
        mensagem: 'Login bem-sucedido',
        usuario: { id: usuario.id, nome: usuario.nome, email }
    });
});

// Upload de arquivos com Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage });

app.post('/upload', upload.single('arquivo'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ erro: 'Nenhum arquivo enviado' });
    }
    res.status(200).json({ mensagem: 'Arquivo enviado com sucesso', arquivo: req.file.filename });
});

// Listar arquivos enviados
app.get('/files', (req, res) => {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
        return res.json([]);
    }

    const arquivos = fs.readdirSync(uploadDir);
    res.json(arquivos);
});

// Documentação da API
app.get('/docs', (req, res) => {
    res.json({
        rotas: {
            '/auth/register': 'POST - Registra um novo usuário',
            '/auth/login': 'POST - Realiza login com email e senha',
            '/users': 'GET - Lista todos os usuários | POST - Cria novo usuário',
            '/users/:id': 'PUT - Atualiza um usuário | DELETE - Remove um usuário',
            '/upload': 'POST - Faz upload de um arquivo (campo: arquivo)',
            '/files': 'GET - Lista arquivos enviados',
            '/docs': 'GET - Exibe documentação da API'
        }
    });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ erro: 'Erro interno do servidor' });
});

// Inicialização
app.listen(PORT, () => {
    console.log(`🚀 Projeto Final rodando em http://localhost:${PORT}`);
});
