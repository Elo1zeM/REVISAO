//LOJA DE ROUPAS e ACESSORIOS

const express = require('express');
const app = express();
const PORT = 3002;

// Middleware para interpretar o corpo das requisições como JSON
app.use(express.json());

// Array para simular um banco de dados em memória
let produtos = [
    // Adicionados 2 produtos iniciais
    { id: 1, nome: 'Chaveiro', preco: 45.00, categoria: 'Acessórios'},
    { id: 2, nome: 'Calça Jeans', preco: 195.00, categoria: 'Calças'},
];

// Variável para controlar o próximo ID a ser usado.
// Começa em 3 porque já temos os IDs 1 e 2.
let proximoId = 3;

// ROTA GET: Listar todos os produtos
app.get('/produtos', (req, res) => {
    // Retorna a lista completa de produtos
    res.json(produtos);
});

// ROTA GET: Buscar produto por ID
app.get('/produtos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const produto = produtos.find(p => p.id === id);
    
    if (produto) {
        res.json(produto);
    } else {
        res.status(404).json({ erro: 'Produto não encontrado!' });
    }
});

// ROTA POST: Criar um novo produto
app.post('/produtos', (req, res) => {
    const { nome, preco, categoria } = req.body;
    
    // Validação básica para garantir que todos os campos foram enviados
    if (!nome || !preco || !categoria) {
        return res.status(400).json({ erro: 'Nome, preço e categoria são obrigatórios' });
    }
    
    // Cria o novo objeto de produto com um ID automático
    const novoProduto = {
        id: proximoId,
        nome: nome,
        preco: preco,
        categoria: categoria
    };
    
    // Incrementa o ID para o próximo produto a ser criado
    proximoId++;
    
    // Adiciona o novo produto ao array "produtos"
    produtos.push(novoProduto);
    
    // Retorna o produto recém-criado com o status 201 (Created)
    res.status(201).json(novoProduto);
});

// ROTA PUT: Atualizar um produto existente
app.put('/produtos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = produtos.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Produto não encontrado' });
    }
    
    // Atualiza o objeto do produto no array
    // Mantém o ID original e atualiza os outros campos com os dados da requisição
    produtos[index] = { ...produtos[index], ...req.body };
    
    res.json(produtos[index]);
});

// ROTA DELETE: Remover um produto
app.delete('/produtos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = produtos.findIndex(p => p.id === id);
    
    if (index === -1) {
        return res.status(404).json({ erro: 'Produto não encontrado' });
    }
    
    // Remove o produto do array usando o índice encontrado
    produtos.splice(index, 1);
    
    // Retorna o status 204 (No Content) para indicar sucesso na remoção
    res.status(204).send();
});

app.listen(PORT, () => {
    console.log(`API rodando em http://localhost:${PORT}`);
});